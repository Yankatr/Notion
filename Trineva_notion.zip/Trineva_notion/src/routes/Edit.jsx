import { useLoaderData, useNavigate, useParams } from "react-router-dom";
import { useState } from "react";

export const loader = async ({ params: { id } }) => {
  const note = await fetch(`http://localhost:5001/notes/${id}`).then((r) => {
    if (!r.ok) throw new Error(`Fetch error: ${r.status}`);
    return r.json();
  });
  return { note };
};

export default function Edit() {
  const { note } = useLoaderData();
  const { authorId } = useParams();

  const [title, setTitle] = useState(note.title);
  const [text, setText] = useState(note.text);
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handleSave = async () => {
    if (title.trim() === "") {
      setError("you can not add an empty name or name only from spaces");
      setTitle("");
    } else {
      await fetch(`http://localhost:5001/notes/${note.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ...note, title: title.trim(), text }),
      });
      navigate(`/notes/${authorId}/${note.id}`);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="w-full flex justify-between items-center mb-5">
        <div className="w-1/4 flex justify-start items-center">
          <button
            onClick={() => navigate(-1)}
            className="  text-center text-black font-semibold text-lg  h-10"
          >
            Back
          </button>
        </div>
        <h1 className="w-1/2 text-3xl  font-bold">Edit note</h1>
        <div className="w-1/4"></div>
      </div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        type="text"
        placeholder="Name"
        className="h-10 border-2 border-red-700 pl-2 rounded-lg text-lg "
      />
      {error && <div className="text-red-500">{error}</div>}
      <textarea
        defaultValue={text}
        onChange={(e) => setText(e.target.value)}
        rows={10}
        placeholder="Note text"
        className="border-2 border-red-700 pl-2 rounded-lg pt-2 text-lg"
      ></textarea>
      <button
        onClick={handleSave}
        className="text-center bg-red-700 rounded-xl text-white text-xl font-medium  h-14"
      >
        SAVE
      </button>
    </div>
  );
}
