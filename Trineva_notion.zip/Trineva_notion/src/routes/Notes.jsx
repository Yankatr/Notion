import { useState } from "react";
import { useLoaderData, useNavigate, useParams } from "react-router-dom";
import editIcon from "../../public/icons/edit.png";
import trashIcon from "../../public/icons/trash.png";

export const loader = async ({ params: { authorId } }) => {
  const Notes = await fetch(
    `http://localhost:5001/notes?authorId=${authorId}`
  ).then((r) => {
    if (!r.ok) throw new Error(`Fetch error: ${r.status}`);
    return r.json();
  });
  return { Notes };
};

export default function Notes() {
  let { Notes } = useLoaderData();
  const { authorId } = useParams();
  const [notes, setNotes] = useState(Notes);

  const navigate = useNavigate();

  const handleDelete = (e) => {
    e.stopPropagation();
    const id = e.target.parentElement.parentElement.attributes.id.value;

    fetch(`http://localhost:5001/notes/${id}`, {
      method: "DELETE",
    });

    setNotes(notes.filter((note) => note.id != id));
  };

  const handleEdit = (e) => {
    e.stopPropagation();
    const id = e.target.parentElement.parentElement.attributes.id.value;
    navigate(`/notes/${authorId}/${id}/edit`);
  };

  const notesToView = notes.sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="flex flex-col items-center gap-3 pt-4 pb-2">
      <h1 className="w-1/2 text-4xl font-bold">Notes</h1>
      <button
        onClick={() => navigate(`/notes/${authorId}/add`)}
        className="w-full h-12 text-center bg-red-700 rounded-xl text-white text-xl font-bold  "
      >
        Add note
      </button>
      <div className="w-full flex flex-col gap-2">
        {notesToView.map((note) => (
          <div
            key={note.id}
            id={note.id}
            onClick={() => navigate(`/notes/${authorId}/${note.id}`)}
            className=" h-11  flex justify-between items-center w-full px-2 border-red-700 border-2 rounded-xl text-emerald-950 cursor-pointer"
          >
            <div className="flex gap-6">
              <p className=" font-medium">{note.title}</p>
              <p>{new Date(note.createdAt).toLocaleString()}</p>
            </div>
            <div className="flex gap-5">
              <img src={editIcon} onClick={handleEdit} width="17px" />
              <img
                src={trashIcon}
                onClick={handleDelete}
                width="17px"
                className="cursor-pointer"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
