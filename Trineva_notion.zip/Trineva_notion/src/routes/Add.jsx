import { useNavigate, useParams } from "react-router-dom";
import { useState } from "react";

export default function Add() {
  const { authorId } = useParams();
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handleAddNote = async () => {
    if (title.trim() === "") {
      setError("you can not add an empty name or name only from spaces");
      setTitle("");
    } else {
      const newNote = {
        id: Date.now(),
        authorId: authorId,
        title: title.trim(),
        text,
        createdAt: Date.now(),
      };
      await fetch(`http://localhost:5001/notes/`, {
        method: "POST",
        body: JSON.stringify(newNote),
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      });
      navigate(`/notes/${authorId}/${newNote.id}`);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="w-full flex justify-between items-center mb-5">
        <div className="w-1/4 flex justify-start items-center">
          <button
            onClick={() => navigate(-1)}
            className="  text-cente font-bold text-lg  h-10"
          >
            Back
          </button>
        </div>
        <h1 className="w-1/2 text-3xl  font-bold">Create note</h1>
        <div className="w-1/4"></div>
      </div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        type="text"
        placeholder="Name"
        className="h-10 border-2 border-red-700 pl-2 text-md rounded-xl"
      />
      {error && <div className="text-red-500">{error}</div>}
      <textarea
        defaultValue={text}
        onChange={(e) => setText(e.target.value)}
        rows={10}
        placeholder="Note text"
        className="border-2 border-red-700 pl-2 pt-2 text-md rounded-xl"
      ></textarea>
      <button
        onClick={handleAddNote}
        className="text-center bg-red-700 text-white text-xl font-medium  h-14 rounded-xl"
      >
        ADD
      </button>
    </div>
  );
}
